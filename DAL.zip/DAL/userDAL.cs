﻿using BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class userDAL
    {
        public int AddUser(userBO objUserBO)
        {
            UserTable_module2 objuser = new UserTable_module2();

            try
            {
                objuser.FirstName = objUserBO.FirstName;
                objuser.LastName = objUserBO.LastName;
                objuser.Gender = objUserBO.Gender;          

                using (var dbContext = new databaseEntities() )
                {
                    dbContext.UserTable_module2.Add(objuser);
                    dbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {

            }
            return objuser.UserProfileId;
        }

        public int AuthenticateUser(userBO objUserBO)
        {            
            try
            {
                //using (var context = new databaseEntities())
                //{
                //   var whyIsThisNotWorkingMan -_- = context.UserTable_module2
                //                    .Where(b => b.UserProfileId == objUserBO.UserProfileId)
                //                    .FirstOrDefault();
                //}

                databaseEntities de = new databaseEntities();
                var v = de.UserTable_module2.Where(a => a.UserProfileId.Equals(objUserBO.UserProfileId) && a.Password.Equals(objUserBO.Password)).FirstOrDefault();
                if (v != null)
                {
                    //Session["LogedUserID"] = v.Id.ToString();
                    //Session["LogedUserFullname"] = v.FullName.ToString();
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            catch(Exception ex)
            {
                return 0;
            }
            
         
        }

        public userBO GetUser(int userProfileId)
        {
            UserTable_module2 objUser;

            userBO objEmployeeBO = new userBO();

            try
            {
                using (var dbContext = new databaseEntities())
                {
                    objUser = dbContext.UserTable_module2.FirstOrDefault<UserTable_module2>(e => e.UserProfileId == userProfileId);
                }

                if (objUser != null)
                {
                    objEmployeeBO.UserProfileId = objUser.UserProfileId;
                    objEmployeeBO.FirstName = objUser.FirstName;
                    objEmployeeBO.LastName = objUser.LastName;
                }
            }
            catch (Exception ex)
            {

            }
            return objEmployeeBO;
        }


    }
}

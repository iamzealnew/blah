﻿using BO;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class userBLL
    {
        public int AddUser(userBO objUserBO)
        {
            userDAL objUserDAL = new userDAL();
            return objUserDAL.AddUser(objUserBO);
        }
        public int AuthenticateUser(userBO objUserBO)
        {
            userDAL objUserDAL = new userDAL();
            return objUserDAL.AuthenticateUser(objUserBO);
        }

        public userBO GetUser(int profileId)
        {
            userDAL objUserDAL = new userDAL();
            return objUserDAL.GetUser(profileId);
        }

    }
}

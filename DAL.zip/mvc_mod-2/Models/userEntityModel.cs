namespace mvc_mod_2.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class userEntityModel : DbContext
    {
        public userEntityModel()
            : base("name=userEntityModel")
        {
        }

        public virtual DbSet<UserTable_module2> UserTable_module2 { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserTable_module2>()
                .Property(e => e.Password)
                .IsUnicode(false);

            modelBuilder.Entity<UserTable_module2>()
                .Property(e => e.Title)
                .IsUnicode(false);

            modelBuilder.Entity<UserTable_module2>()
                .Property(e => e.FirstName)
                .IsUnicode(false);

            modelBuilder.Entity<UserTable_module2>()
                .Property(e => e.StreetAddress)
                .IsUnicode(false);

            modelBuilder.Entity<UserTable_module2>()
                .Property(e => e.Nationality)
                .IsUnicode(false);

            modelBuilder.Entity<UserTable_module2>()
                .Property(e => e.State)
                .IsUnicode(false);

            modelBuilder.Entity<UserTable_module2>()
                .Property(e => e.TownOrCity)
                .IsUnicode(false);

            modelBuilder.Entity<UserTable_module2>()
                .Property(e => e.EmailAddress)
                .IsUnicode(false);

            modelBuilder.Entity<UserTable_module2>()
                .Property(e => e.CompanyName)
                .IsUnicode(false);

            modelBuilder.Entity<UserTable_module2>()
                .Property(e => e.OfficeAddress)
                .IsUnicode(false);

            modelBuilder.Entity<UserTable_module2>()
                .Property(e => e.CreatedBy)
                .IsUnicode(false);

            modelBuilder.Entity<UserTable_module2>()
                .Property(e => e.ModifiedBy)
                .IsUnicode(false);
        }
    }
}

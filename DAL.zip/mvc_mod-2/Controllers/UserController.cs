﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc_mod_2.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Index()
        {
            var entities = new DAL.databaseEntities();
            return View(entities.UserTable_module2.Where(e => e.UserProfileId == 1001).ToList());
        }
        DAL.databaseEntities _db = new DAL.databaseEntities();

        public ActionResult Edit(int id)
        {
            DAL.UserTable_module2 user = _db.UserTable_module2.Where(x => x.UserProfileId == id).SingleOrDefault();
            return View(user);
        }
        [HttpPost]
        public ActionResult Edit(DAL.UserTable_module2 model)
        {
            DAL.UserTable_module2 user = _db.UserTable_module2.Where(x => x.UserProfileId == model.UserProfileId).SingleOrDefault();
            if (user != null)
            {
                _db.Entry(user).CurrentValues.SetValues(model);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(model);
        }
    }
}
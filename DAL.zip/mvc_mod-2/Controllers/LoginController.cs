﻿using BLL;
using BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc_mod_2.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult AuthenticateUser(int profile_id, string password)
        {
            if (ModelState.IsValid)
            {
                userBO objUserBO = new userBO();
                objUserBO.UserProfileId = profile_id;
                objUserBO.Password = password;
                //objUserBO.Salary = int.Parse(Request.Form["Salary"].ToString());
                userBLL objUsereBLL = new userBLL();
                int intProfileId = objUsereBLL.AuthenticateUser(objUserBO);

                if (intProfileId == 1)
                {
                    ViewBag.Message = String.Format("Success: Employee added. Employee Id is {0}", intProfileId);
                    return View("AuthenticateUser");
                }
                else
                {
                    ViewBag.Message = "Error while adding employee. Please try again";
                    return View("AuthenticateUser");
                }
            }
            else
            {
                ViewBag.Message = "Error while adding employee. Please try again";
                return View("RegisterUser");
                //return View("AddEmployee", objEmployeeViewModel);
            }
        }
    }
}
﻿using BLL;
using BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc_mod_2.Controllers
{
    public class SignUpController : Controller
    {
        // GET: SignUp
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult RegisterUser(string first_name, string last_name)
        {
            if (ModelState.IsValid)
            {
                userBO objUserBO = new userBO();
                objUserBO.FirstName = first_name;
                objUserBO.LastName = last_name;
                //objUserBO.Salary = int.Parse(Request.Form["Salary"].ToString());
                             

                userBLL objUsereBLL = new userBLL();
                int intProfileId = objUsereBLL.AddUser(objUserBO);

                if (intProfileId > 1)
                {
                    ViewBag.Message = String.Format("Success: Employee added. Employee Id is {0}", intProfileId);
                    return View("RegisterUser");
                }
                else
                {
                    ViewBag.Message = "Error while adding employee. Please try again";
                    return View("RegisterUser");

                }
            }
            else
            {
                ViewBag.Message = "Error while adding employee. Please try again";
                return View("RegisterUser");

                //return View("AddEmployee", objEmployeeViewModel);
            }
        }

    }
}
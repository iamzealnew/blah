﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class userBO
    {
        [Key]
        public int UserProfileId { get; set; }
        public int UserId { get; set; }
        public string Password { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public bool? Gender { get; set; }
        public string StreetAddress { get; set; }
        public string Nationality { get; set; }
        public string State { get; set; }
        public string TownOrCity { get; set; }
        public int? ZipCode { get; set; }
        public long? MobileNumber { get; set; }
        public long? AlternatePhone { get; set; }
        public long? PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public string CompanyName { get; set; }
        public string OfficeAddress { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}
